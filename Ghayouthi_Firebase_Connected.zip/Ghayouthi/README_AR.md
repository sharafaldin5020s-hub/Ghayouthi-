# غيوثي — Ghayouthi

هذه نسخة أولية حقيقية لتطبيق Android باسم **غيوثي**، بهوية بنية داكنة أصلية مستوحاة من تطبيقات الكاميرا الاجتماعية، وليست نسخة من شعار أو واجهة Snapchat.

## ما تم تجهيزه
- Android + Kotlin + Jetpack Compose.
- استهداف Android 16 / API 36.
- شاشة دخول أولية.
- كاميرا مباشرة باستخدام CameraX.
- شاشة أصدقاء.
- شاشة محادثات.
- شاشة ملف شخصي.
- شريط تنقل سفلي.
- تجهيز تبعيات Firebase Authentication وCloud Firestore.

## ما يحتاج الربط قبل الإطلاق
1. إنشاء مشروع Firebase وإضافة `google-services.json`.
2. ربط تسجيل الدخول الحقيقي.
3. إنشاء قاعدة بيانات المحادثات والرسائل.
4. إضافة تخزين الصور والإشعارات.
5. إنشاء تطبيق Meta وربط Facebook Login بمعلومات التطبيق الحقيقية.
6. إضافة سياسة الخصوصية وبيانات Data Safety.
7. إنشاء نسخة Release موقعة ثم رفع AAB إلى Google Play.

> لا توجد داخل هذا المشروع مفاتيح Facebook أو Firebase حقيقية، لذلك لا يوجد ادعاء بأن تسجيل الدخول أو الدردشة السحابية يعملان قبل إعداد الحسابات المطلوبة.

## ملاحظات
- مع متطلبات Google Play الحالية، التطبيقات الجديدة يجب أن تستهدف Android 16 / API 36 أو أعلى.
- Firebase يوصي باستخدام Firebase Android BoM لإدارة إصدارات مكتبات Firebase.
- لا تستخدم أي شعار أو أصل بصري مملوك لـ Snapchat؛ حافظنا على هوية غيوثي الخاصة.

## الحزمة
افتح المشروع في Android Studio أو استخدم بيئة بناء Android سحابية، ثم نفّذ مزامنة Gradle وبناء نسخة Debug/Release.


## تحديث Firebase
- تم تفعيل Firebase Authentication بالبريد الإلكتروني وكلمة المرور داخل التطبيق.
- تم تفعيل دردشة مباشرة تجريبية محفوظة في Cloud Firestore ضمن `chats/global/messages`.
- لم يتم وضع `google-services.json` داخل المستودع. تهيئة Firebase الحالية تستخدم إعداد تطبيق Firebase الذي تم توفيره للمشروع.
- قبل الاختبار: فعّل **Email/Password** من Firebase Authentication، وأنشئ Firestore Database، ثم طبّق قواعد `firestore.rules`.
- إعداد Facebook Login ما زال يحتاج إنشاء تطبيق Meta وربط App ID/Client Token الحقيقيين.
