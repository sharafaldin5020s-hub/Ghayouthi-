package com.ghayouthi.app

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

/** Initializes the Firebase Android app without committing google-services.json to the repository.
 * The values below come from the Firebase Android app configuration supplied for Ghayouthi.
 * The API key is a Firebase client key, not a server credential; restrict it in Google Cloud.
 */
object FirebaseServices {
    private const val APPLICATION_ID = "1:496071195128:android:c85b7bdc06c386de0ebe0d"
    private const val PROJECT_ID = "ghayouthi-4648a"
    private const val API_KEY = "AIzaSyBfZkv5wxEksNSEFBuEKj805HeK-5eAXkU"
    private const val STORAGE_BUCKET = "ghayouthi-4648a.firebasestorage.app"

    fun initialize(context: Context): Boolean {
        if (FirebaseApp.getApps(context).isNotEmpty()) return true
        val options = FirebaseOptions.Builder()
            .setApplicationId(APPLICATION_ID)
            .setProjectId(PROJECT_ID)
            .setApiKey(API_KEY)
            .setStorageBucket(STORAGE_BUCKET)
            .build()
        return FirebaseApp.initializeApp(context, options) != null
    }
}
