package com.ghayouthi.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch

private val GhayouthiBrown = Color(0xFF24150F)
private val GhayouthiBrown2 = Color(0xFF3A241A)
private val GhayouthiGold = Color(0xFFD8A15D)
private val GhayouthiCream = Color(0xFFF7EFE7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseServices.initialize(this)
        setContent { GhayouthiApp() }
    }
}

@Composable
fun GhayouthiApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var tab by remember { mutableIntStateOf(1) }
    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    MaterialTheme {
        Surface(color = GhayouthiBrown, modifier = Modifier.fillMaxSize()) {
            if (user == null) {
                LoginScreen(auth)
            } else {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            0 -> FriendsScreen()
                            1 -> CameraScreen()
                            2 -> ChatScreen(user!!.uid, user!!.email ?: "مستخدم")
                            3 -> ProfileScreen(user!!.email ?: "مستخدم", onLogout = { auth.signOut() })
                        }
                    }
                    BottomBar(tab) { tab = it }
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(auth: FirebaseAuth) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier.fillMaxSize().background(GhayouthiBrown).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(104.dp).clip(CircleShape).background(GhayouthiGold), contentAlignment = Alignment.Center) {
            Text("غ", color = GhayouthiBrown, fontSize = 52.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(20.dp))
        Text("غيوثي", color = GhayouthiCream, fontSize = 42.sp, fontWeight = FontWeight.Bold)
        Text(if (register) "إنشاء حساب جديد" else "تسجيل الدخول", color = GhayouthiGold, fontSize = 17.sp)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(email, { email = it }, label = { Text("البريد الإلكتروني") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, singleLine = true)
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = !busy,
            onClick = {
                if (email.isBlank() || password.length < 6) {
                    message = "أدخل بريدًا صحيحًا وكلمة مرور من 6 أحرف على الأقل"
                    return@Button
                }
                busy = true
                val task = if (register) auth.createUserWithEmailAndPassword(email.trim(), password)
                else auth.signInWithEmailAndPassword(email.trim(), password)
                task.addOnCompleteListener { result ->
                    busy = false
                    if (!result.isSuccessful) message = result.exception?.localizedMessage ?: "حدث خطأ"
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GhayouthiGold),
            shape = RoundedCornerShape(18.dp)
        ) { Text(if (register) "إنشاء الحساب" else "دخول", color = GhayouthiBrown, fontWeight = FontWeight.Bold) }
        TextButton(onClick = { register = !register; message = "" }) {
            Text(if (register) "لدي حساب بالفعل" else "إنشاء حساب جديد", color = GhayouthiGold)
        }
        if (message.isNotBlank()) Text(message, color = Color(0xFFFFB4A8), fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Text("تسجيل Facebook سيُضاف بعد إعداد تطبيق Meta وربطه بهذا المشروع.", color = Color(0xFFBBA99C), fontSize = 12.sp)
    }
}

@Composable
private fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    LaunchedEffect(Unit) { if (!hasPermission) launcher.launch(Manifest.permission.CAMERA) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (hasPermission) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        val future = ProcessCameraProvider.getInstance(ctx)
                        future.addListener({
                            val provider = future.get()
                            val preview = Preview.Builder().build().also { it.surfaceProvider = surfaceProvider }
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                        }, ContextCompat.getMainExecutor(ctx))
                    }
                }, Modifier.fillMaxSize()
            )
            Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Text("غيوثي", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.fillMaxWidth().padding(bottom = 20.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(78.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(GhayouthiGold))
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("نحتاج إذن الكاميرا", color = Color.White, fontSize = 20.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("السماح بالكاميرا") }
            }
        }
    }
}

@Composable
private fun FriendsScreen() {
    val people = listOf("أحمد", "محمد", "سارة", "مريم", "خالد")
    Column(Modifier.fillMaxSize().background(GhayouthiCream).padding(18.dp)) {
        Text("الأصدقاء", color = GhayouthiBrown, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("قائمة الأصدقاء ستصبح مرتبطة بـ Firestore في المرحلة التالية.", color = GhayouthiBrown2, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(people) { name ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(GhayouthiGold), contentAlignment = Alignment.Center) { Text(name.take(1), color = GhayouthiBrown, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp)); Text(name, color = GhayouthiBrown, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

private data class ChatMessage(val id: String, val senderId: String, val sender: String, val text: String)

@Composable
private fun ChatScreen(uid: String, email: String) {
    val db = remember { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    var messages by remember { mutableStateOf(emptyList<ChatMessage>()) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val list = db.collection("chats").document("global").collection("messages")
        .orderBy("createdAt", Query.Direction.ASCENDING)
    DisposableEffect(Unit) {
        val registration = list.addSnapshotListener { snapshot, e ->
            if (e != null) { error = e.localizedMessage ?: "تعذر تحميل الرسائل"; return@addSnapshotListener }
            messages = snapshot?.documents?.map { d ->
                ChatMessage(d.id, d.getString("senderId") ?: "", d.getString("sender") ?: "مستخدم", d.getString("text") ?: "")
            } ?: emptyList()
        }
        onDispose { registration.remove() }
    }
    Column(Modifier.fillMaxSize().background(GhayouthiCream).padding(18.dp)) {
        Text("الدردشة المباشرة", color = GhayouthiBrown, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("غرفة غيوثي التجريبية — الرسائل محفوظة في Firestore", color = GhayouthiBrown2, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), reverseLayout = false) {
            items(messages) { m ->
                val mine = m.senderId == uid
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                    Text(m.sender, color = GhayouthiBrown2, fontSize = 11.sp)
                    Card(colors = CardDefaults.cardColors(containerColor = if (mine) GhayouthiGold else Color.White), shape = RoundedCornerShape(16.dp)) {
                        Text(m.text, color = GhayouthiBrown, modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFF9B3B2E), fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("اكتب رسالة") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                val clean = text.trim()
                if (clean.isEmpty()) return@Button
                db.collection("chats").document("global").collection("messages").add(
                    mapOf("senderId" to uid, "sender" to email, "text" to clean, "createdAt" to FieldValue.serverTimestamp())
                ).addOnFailureListener { error = it.localizedMessage ?: "فشل إرسال الرسالة" }
                text = ""
            }) { Text("إرسال") }
        }
    }
}

@Composable
private fun ProfileScreen(email: String, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().background(GhayouthiCream).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Box(Modifier.size(96.dp).clip(CircleShape).background(GhayouthiGold), contentAlignment = Alignment.Center) { Text(email.take(1).uppercase(), color = GhayouthiBrown, fontSize = 42.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        Text("حساب غيوثي", color = GhayouthiBrown, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(email, color = GhayouthiBrown2)
        Spacer(Modifier.height(30.dp))
        Text("تسجيل الدخول مرتبط الآن بـ Firebase Authentication.", color = GhayouthiBrown2, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onLogout) { Text("تسجيل الخروج", color = Color(0xFF9B3B2E)) }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelected: (Int) -> Unit) {
    val labels = listOf("أصدقاء", "كاميرا", "دردشة", "حسابي")
    Row(Modifier.fillMaxWidth().background(GhayouthiBrown).navigationBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
        labels.forEachIndexed { index, label ->
            Column(Modifier.clip(RoundedCornerShape(14.dp)).clickable { onSelected(index) }.padding(horizontal = 13.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(when (index) { 0 -> "👥"; 1 -> "📷"; 2 -> "💬"; else -> "👤" }, fontSize = 20.sp)
                Text(label, color = if (selected == index) GhayouthiGold else Color(0xFFC8B9AE), fontSize = 11.sp)
            }
        }
    }
}
