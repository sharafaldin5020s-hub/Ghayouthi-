package com.ghayouthi.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat

private val GhayouthiBrown = Color(0xFF24150F)
private val GhayouthiBrown2 = Color(0xFF3A241A)
private val GhayouthiGold = Color(0xFFD8A15D)
private val GhayouthiCream = Color(0xFFF7EFE7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GhayouthiApp() }
    }
}

@Composable
fun GhayouthiApp() {
    var tab by remember { mutableIntStateOf(1) }
    var signedIn by remember { mutableStateOf(false) }

    MaterialTheme {
        Surface(color = GhayouthiBrown, modifier = Modifier.fillMaxSize()) {
            if (!signedIn) {
                LoginScreen(onContinue = { signedIn = true })
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(1f)) {
                        when (tab) {
                            0 -> FriendsScreen()
                            1 -> CameraScreen()
                            2 -> ChatScreen()
                            3 -> ProfileScreen(onLogout = { signedIn = false })
                        }
                    }
                    BottomBar(selected = tab, onSelected = { tab = it })
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(onContinue: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GhayouthiBrown)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(104.dp)
                .clip(CircleShape)
                .background(GhayouthiGold),
            contentAlignment = Alignment.Center
        ) {
            Text("غ", color = GhayouthiBrown, fontSize = 52.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(20.dp))
        Text("غيوثي", color = GhayouthiCream, fontSize = 42.sp, fontWeight = FontWeight.Bold)
        Text(
            "صوّر • شارك • تحدث",
            color = GhayouthiGold,
            fontSize = 17.sp,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(42.dp))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GhayouthiGold),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("متابعة", color = GhayouthiBrown, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "زر فيسبوك الحقيقي سيتم ربطه بعد إضافة بيانات Meta الخاصة بالتطبيق.",
            color = Color(0xFFBBA99C),
            fontSize = 12.sp
        )
    }
}

@Composable
private fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasPermission = granted }

    LaunchedEffect(Unit) {
        if (!hasPermission) launcher.launch(Manifest.permission.CAMERA)
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (hasPermission) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                        cameraProviderFuture.addListener({
                            val provider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build()
                            preview.surfaceProvider = surfaceProvider
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview
                            )
                        }, ContextCompat.getMainExecutor(ctx))
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            Column(
                modifier = Modifier.fillMaxSize().padding(22.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("غيوثي", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("⚙", color = Color.White, fontSize = 24.sp)
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier.size(78.dp).clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier.size(64.dp).clip(CircleShape)
                                .background(GhayouthiGold)
                        )
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("نحتاج إذن الكاميرا", color = Color.White, fontSize = 20.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) {
                    Text("السماح بالكاميرا")
                }
            }
        }
    }
}

@Composable
private fun FriendsScreen() {
    val people = listOf("أحمد", "محمد", "سارة", "مريم", "خالد")
    Column(modifier = Modifier.fillMaxSize().background(GhayouthiCream).padding(18.dp)) {
        Text("الأصدقاء", color = GhayouthiBrown, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("شارك لحظاتك مع أصدقائك", color = GhayouthiBrown2, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(people) { name ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(GhayouthiGold),
                            contentAlignment = Alignment.Center
                        ) { Text(name.take(1), color = GhayouthiBrown, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Text(name, color = GhayouthiBrown, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatScreen() {
    val chats = listOf(
        "أحمد" to "أرسل لك صورة جديدة",
        "سارة" to "أراك لاحقًا 👋",
        "خالد" to "هل رأيت الصورة؟"
    )
    Column(modifier = Modifier.fillMaxSize().background(GhayouthiCream).padding(18.dp)) {
        Text("المحادثات", color = GhayouthiBrown, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(chats) { (name, message) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(50.dp).clip(CircleShape).background(GhayouthiBrown2),
                            contentAlignment = Alignment.Center
                        ) { Text(name.take(1), color = GhayouthiGold, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(name, color = GhayouthiBrown, fontWeight = FontWeight.Bold)
                            Text(message, color = Color(0xFF806F63), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(onLogout: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(GhayouthiCream).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(28.dp))
        Box(
            modifier = Modifier.size(96.dp).clip(CircleShape).background(GhayouthiGold),
            contentAlignment = Alignment.Center
        ) { Text("ش", color = GhayouthiBrown, fontSize = 42.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        Text("مستخدم غيوثي", color = GhayouthiBrown, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("@ghayouthi_user", color = GhayouthiBrown2)
        Spacer(Modifier.height(30.dp))
        Button(
            onClick = {},
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = GhayouthiBrown),
            shape = RoundedCornerShape(16.dp)
        ) { Text("تعديل الملف الشخصي") }
        TextButton(onClick = onLogout) { Text("تسجيل الخروج", color = Color(0xFF9B3B2E)) }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelected: (Int) -> Unit) {
    val labels = listOf("أصدقاء", "كاميرا", "دردشة", "حسابي")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(GhayouthiBrown)
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        labels.forEachIndexed { index, label ->
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelected(index) }
                    .padding(horizontal = 13.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    when (index) {
                        0 -> "👥"
                        1 -> "📷"
                        2 -> "💬"
                        else -> "👤"
                    },
                    fontSize = 20.sp
                )
                Text(
                    label,
                    color = if (selected == index) GhayouthiGold else Color(0xFFC8B9AE),
                    fontSize = 11.sp
                )
            }
        }
    }
}
